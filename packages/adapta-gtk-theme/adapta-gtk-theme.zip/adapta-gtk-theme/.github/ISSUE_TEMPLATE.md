**Reporter info**

 ```
 * Distribution -
 * Gtk+ 3.0 version -
 * Desktop environment -
 * Display server protocol - X11 or Wayland?
 ```

**Adapta version (if you knew)**



**Related Application and/or Shell theming (or name of widget)**



**Actual issue**



**Steps to reproduce (if you knew)**



**Expected behaviour**



**Other Note (feature-request, question, etc...)**


