local function hello()
    return "hello from lua"
end

return {
    hello = hello
}
