<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr" sourcelanguage="en">
<context>
    <name>qml-i18n</name>
    <message>
        <location filename="../qml-i18n.qml" line="68"/>
        <source>Hello</source>
        <translation>Bonjour</translation>
    </message>
</context>
</TS>
