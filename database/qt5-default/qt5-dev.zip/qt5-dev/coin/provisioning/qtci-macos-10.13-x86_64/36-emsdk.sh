#!/usr/bin/env bash

set -ex

# shellcheck source=../common/unix/emsdk.sh
source "${BASH_SOURCE%/*}/../common/unix/emsdk.sh"
