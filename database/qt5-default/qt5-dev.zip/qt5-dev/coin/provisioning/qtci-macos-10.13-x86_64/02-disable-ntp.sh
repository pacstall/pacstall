#!/usr/bin/env bash

# shellcheck source=../common/unix/disable-ntp_macos.sh
source "${BASH_SOURCE%/*}/../common/unix/disable-ntp_macos.sh"
