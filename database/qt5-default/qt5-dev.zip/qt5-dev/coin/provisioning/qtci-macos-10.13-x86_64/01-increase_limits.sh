#!/bin/sh

"$(dirname "$0")"/../common/macos/increase_limits.sh
