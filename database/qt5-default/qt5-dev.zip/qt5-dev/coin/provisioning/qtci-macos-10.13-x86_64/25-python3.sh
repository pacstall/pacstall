#!/usr/bin/env bash
set -ex

# shellcheck source=../common/macos/python3.sh
source "${BASH_SOURCE%/*}/../common/macos/python3.sh"
