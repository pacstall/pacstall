#!/usr/bin/env bash
set -ex

# shellcheck source=../common/macos/disable_spotlight.sh
source "${BASH_SOURCE%/*}/../common/macos/disable_spotlight.sh"
