. "$PSScriptRoot\..\common\windows\install-msys2.ps1"
