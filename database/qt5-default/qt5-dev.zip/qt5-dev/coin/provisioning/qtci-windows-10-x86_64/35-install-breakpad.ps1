. "$PSScriptRoot\..\common\windows\install-breakpad.ps1"
