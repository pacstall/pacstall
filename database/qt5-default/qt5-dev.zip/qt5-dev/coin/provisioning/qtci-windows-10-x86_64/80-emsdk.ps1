. "$PSScriptRoot\..\common\windows\emsdk.ps1"

