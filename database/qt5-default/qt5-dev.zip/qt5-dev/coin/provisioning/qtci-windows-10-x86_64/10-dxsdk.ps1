. "$PSScriptRoot\..\common\windows\dxsdk.ps1"
