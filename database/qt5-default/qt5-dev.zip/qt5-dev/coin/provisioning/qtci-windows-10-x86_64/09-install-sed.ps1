. "$PSScriptRoot\..\common\windows\install-sed.ps1"
