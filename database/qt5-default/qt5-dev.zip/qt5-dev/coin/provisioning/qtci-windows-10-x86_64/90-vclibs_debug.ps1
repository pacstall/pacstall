. "$PSScriptRoot\..\common\windows\vclibs_debug.ps1"

Install-VCLibsDebug X64
