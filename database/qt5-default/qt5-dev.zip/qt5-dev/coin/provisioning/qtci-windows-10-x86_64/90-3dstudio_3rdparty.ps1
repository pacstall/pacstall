. "$PSScriptRoot\..\common\windows\3dstudio_3rdparty.ps1"
