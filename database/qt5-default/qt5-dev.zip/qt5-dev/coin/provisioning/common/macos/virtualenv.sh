#!/usr/bin/env bash
# Will install virtual env for python
sudo pip install virtualenv
