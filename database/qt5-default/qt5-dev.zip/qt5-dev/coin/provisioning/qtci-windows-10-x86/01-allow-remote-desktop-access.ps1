. "$PSScriptRoot\..\common\windows\allow-remote-desktop-access.ps1"
