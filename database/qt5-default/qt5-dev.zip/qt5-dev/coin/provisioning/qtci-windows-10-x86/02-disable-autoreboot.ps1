. "$PSScriptRoot\..\common\windows\disable-autoreboot.ps1"
