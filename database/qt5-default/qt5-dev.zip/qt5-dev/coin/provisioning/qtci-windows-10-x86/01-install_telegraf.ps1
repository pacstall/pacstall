. "$PSScriptRoot\..\common\windows\install_telegraf.ps1"
