. "$PSScriptRoot\..\common\windows\install-ruby.ps1"
