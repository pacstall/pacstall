. "$PSScriptRoot\..\common\windows\disable-clean-manager.ps1"
