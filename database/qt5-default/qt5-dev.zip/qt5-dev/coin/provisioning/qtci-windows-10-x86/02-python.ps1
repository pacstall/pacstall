. "$PSScriptRoot\..\common\windows\python.ps1" 32
