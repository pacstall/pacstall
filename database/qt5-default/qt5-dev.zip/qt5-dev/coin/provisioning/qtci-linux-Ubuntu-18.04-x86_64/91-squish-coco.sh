#!/bin/bash

# shellcheck source=../common/linux/squish-coco.sh
source "${BASH_SOURCE%/*}/../common/linux/squish-coco.sh"
