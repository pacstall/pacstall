#!/usr/bin/env bash

BASEDIR=$(dirname "$0")
"$BASEDIR/../common/unix/libclang.sh"
