/*
 * Copyright 2006-2016 Christian Stigen Larsen
 * Distributed under the GNU General Public License (GPL) v2.
 */

#ifndef INC_JP2A_ASPECT_RATIO_H

void aspect_ratio(const int jpeg_width, const int jpeg_height);

#endif
