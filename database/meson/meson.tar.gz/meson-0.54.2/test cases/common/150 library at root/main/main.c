extern int fn(void);

int main(void) {
    return 1 + fn();
}
