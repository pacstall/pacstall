#ifndef PROG_H
// Header guards for PCH confuse msvc in some situations.
// Using them here makes sure we handle this correctly.
#define PROG_H
#include<stdio.h>
#endif
