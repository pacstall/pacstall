#ifndef MESON_INCLUDE_IMPL
#error "MESON_INCLUDE_IMPL is not defined"
#endif // !MESON_INCLUDE_IMPL

cmModClass::cmModClass(string foo) {
  str = foo + " World";
}
