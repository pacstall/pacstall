// Fill out your copyright notice in the Description page of Project Settings.

#include "Liblua.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_GAME_MODULE(FDefaultGameModuleImpl, Liblua);
