in each of the subdirs here is a simple CMakeLists.txt which does a very
basic test for one of the cmake modules in the modules/ directory.
To run them, create a build directory, run cmake and check the output.
(yes, this can of course be enhanced, but it's better than nothing).

Alex
