.. ecm-module:: ../../modules/ECMFindModuleHelpers.cmake
