.. ecm-module:: ../../modules/ECMSetupVersion.cmake
