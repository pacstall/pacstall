.. ecm-module:: ../../modules/ECMGenerateQmlTypes.cmake
