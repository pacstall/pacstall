.. ecm-module:: ../../modules/ECMGeneratePkgConfigFile.cmake
