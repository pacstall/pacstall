.. ecm-module:: ../../modules/ECMSetupQtPluginMacroNames.cmake
