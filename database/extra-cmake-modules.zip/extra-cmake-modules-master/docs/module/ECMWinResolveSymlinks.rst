.. ecm-module:: ../../modules/ECMWinResolveSymlinks.cmake
