.. ecm-module:: ../../find-modules/FindPng2Ico.cmake
