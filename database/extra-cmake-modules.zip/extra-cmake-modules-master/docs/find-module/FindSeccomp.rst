.. ecm-module:: ../../find-modules/FindSeccomp.cmake
