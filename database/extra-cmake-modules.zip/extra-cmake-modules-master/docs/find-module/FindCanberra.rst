.. ecm-module:: ../../find-modules/FindCanberra.cmake
