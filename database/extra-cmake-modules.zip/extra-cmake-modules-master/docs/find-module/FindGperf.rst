.. ecm-module:: ../../find-modules/FindGperf.cmake
