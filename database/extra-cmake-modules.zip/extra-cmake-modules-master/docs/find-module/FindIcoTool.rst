.. ecm-module:: ../../find-modules/FindIcoTool.cmake
