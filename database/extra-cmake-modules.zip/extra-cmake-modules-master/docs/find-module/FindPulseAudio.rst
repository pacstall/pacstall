.. ecm-module:: ../../find-modules/FindPulseAudio.cmake
