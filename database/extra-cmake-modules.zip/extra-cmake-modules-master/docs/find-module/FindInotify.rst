.. ecm-module:: ../../find-modules/FindInotify.cmake
