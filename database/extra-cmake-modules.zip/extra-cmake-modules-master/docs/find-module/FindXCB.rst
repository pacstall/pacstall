.. ecm-module:: ../../find-modules/FindXCB.cmake
