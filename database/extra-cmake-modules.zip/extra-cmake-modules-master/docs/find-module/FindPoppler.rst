.. ecm-module:: ../../find-modules/FindPoppler.cmake
