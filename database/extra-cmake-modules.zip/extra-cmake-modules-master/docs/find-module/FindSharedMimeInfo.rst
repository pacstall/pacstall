.. ecm-module:: ../../find-modules/FindSharedMimeInfo.cmake
