.. ecm-module:: ../../kde-modules/KDEPackageAppTemplates.cmake
