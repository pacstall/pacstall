.. ecm-module:: ../../kde-modules/KDEFrameworkCompilerSettings.cmake
