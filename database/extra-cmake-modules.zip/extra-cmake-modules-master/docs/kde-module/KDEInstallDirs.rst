.. ecm-module:: ../../kde-modules/KDEInstallDirs.cmake
