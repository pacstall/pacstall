#include "testhelper.h"

int main()
{
    make_test_file("test8.txt");
    return 0;
}

