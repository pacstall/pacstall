
#include "subdirfile.h"

int SubdirObject::mul(int a, int b)
{
  return a * b;
}
