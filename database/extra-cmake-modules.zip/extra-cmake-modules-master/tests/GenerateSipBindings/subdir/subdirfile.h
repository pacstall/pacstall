
#pragma once

class SubdirObject
{
public:
    int mul(int a, int b);
};
